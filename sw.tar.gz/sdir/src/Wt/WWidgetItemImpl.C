/*
 * Copyright (C) 2016 Emweb bv, Herent, Belgium.
 *
 * See the LICENSE file for terms of use.
 */

#include "Wt/WWidgetItemImpl.h"

namespace Wt {

WWidgetItemImpl::~WWidgetItemImpl()
{ }

}
